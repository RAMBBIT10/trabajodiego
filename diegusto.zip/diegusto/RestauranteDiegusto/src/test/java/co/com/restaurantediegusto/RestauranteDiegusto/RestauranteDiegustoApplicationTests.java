package co.com.restaurantediegusto.RestauranteDiegusto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestauranteDiegustoApplicationTests {

	@Test
	void contextLoads() {
	}

}
