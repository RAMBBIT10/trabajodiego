package co.com.restaurantediegusto.RestauranteDiegusto.model;

public enum EstadoPedido {
    PENDIENTE,
    CANCELADO,
    CERRADO
}
